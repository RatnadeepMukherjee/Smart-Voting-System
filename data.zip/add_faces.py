import cv2
import pickle  #used for storing pkl file where face data will be stored in the form of texts so that the size will be less. 
import numpy as np #numpy array like storing 50 images with 50 names of a single person for better accuracy
import os #for creating and reading the files. 

if not os.path.exists('data/'):
    os.makedirs('data/')  #if data folder doesnot exsist then a data folder will be created. 

video = cv2.VideoCapture(0) #to turn on the webcam , 0 means 1st camera and if the number of cameras will increase then the index will change to 1, 2 and so on. 
facedetect= cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml') #trained model for face detection
faces_data = []


i=0
name = input("Enter your aadhar number: ")
framesTotal = 51 #number of images we want to store for ta single person
captureAfterFrame=2 #gap or pause between two frames

while True:
    ret, frame = video.read()#read the pictures captured by the camera
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY) #converts colour photograph to grayscale
    faces=facedetect.detectMultiScale(gray, 1.3 ,5)#detect faces from the frame
    for (x, y, w, h) in faces:
        crop_img = frame[y:y+h, x:x+w]
        resized_img = cv2.resize(crop_img, (50,50))
        if len(faces_data)<=framesTotal and i%captureAfterFrame==0:
            faces_data.append(resized_img)
        i=i+1
        cv2.putText(frame, str(len(faces_data)),(50,50), cv2.FONT_HERSHEY_COMPLEX, 1, (50,50,255), 1)    
        cv2.rectangle(frame, (x,y), (x+w, y+h), (50,50,255),1)

    cv2.imshow('frame', frame)   
    k=cv2.waitKey(1)
    if k==ord('q') or len(faces_data) >= framesTotal:
        break

video.release()
cv2.destroyAllWindows()


#print(len(faces_data))

faces_data = np.asarray(faces_data)
faces_data = faces_data.reshape((framesTotal, -1))
print(faces_data)


if 'names.pkl' not in os.listdir('data/'): 
    names=[name]*framesTotal
    with open('data/names.pkl', 'wb') as f:
        pickle.dump(names,f)
else:
    with open('data/names.pkl', 'rb') as f:
        names=pickle.load(f)        
    names=names+[name]*framesTotal
    with open('data/names.pkl', 'wb') as f:
        pickle.dump(names,f)


if 'faces_data.pkl' not in os.listdir('data/'):
    with open('data/faces_data.pkl', 'wb') as f:
        pickle.dump(faces_data,f)
else:
    with open('data/faces_data.pkl', 'rb') as f:
        faces=pickle.load(f)        
    faces=np.append(faces,faces_data, axis=0)
    with open('data/faces_data.pkl', 'wb') as f:
        pickle.dump(faces,f)
     